#!/usr/bin/env bash
echo "bye!"